echo off

echo Creating backup copy of old book.bin

copy book.bin book.bin.old

echo Unpacking new opening book

bookinst

echo Installation complete
